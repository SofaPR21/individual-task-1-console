namespace индивидуальное_задание_2_zykova
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            try
            {
                //читаем формулу из файла
                string formula = ReadFormulaFromFile("formula.txt");

                int result = Formula(formula);
                label1.Text = "Результат: " + result;
            }
            catch (Exception ex)
            {
                label1.Text = "Ошибка: " + ex.Message;
            }
        }

        //чтение формулы из файла
        private string ReadFormulaFromFile(string filePath)
        {
            //проверяем, существует ли файл
            if (!File.Exists(filePath))
            {
                throw new FileNotFoundException("Файл не найден: " + filePath);
            }

            return File.ReadLines(filePath).First();
        }

        private int Formula(string formula)
        {
            Stack<int> stack = new Stack<int>();

            //разделяем строку формулы по знакам
            string[] znak = formula.Split(new char[] { '(', ')', ',', '=' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var znaki in znak.Reverse())
            {
                //если знак - число, помещаем в стек
                if (int.TryParse(znaki, out int num))
                {
                    stack.Push(num);
                }
                else 
                if (znaki.StartsWith("M"))
                {
                    //проверяем, что в стеке достаточно значений
                    if (stack.Count < 2) 
                        throw new ArgumentException("Неверная формула.");
                    int value1 = stack.Pop();
                    int value2 = stack.Pop();
                    stack.Push(Math.Max(value1, value2));
                }
                else 
                if (znaki.StartsWith("m"))
                {
                    //проверка
                    if (stack.Count < 2) 
                        throw new ArgumentException("Неверная формула.");
                    int value1 = stack.Pop();
                    int value2 = stack.Pop();
                    stack.Push(Math.Min(value1, value2));
                }
            }
            return stack.Pop();
        }
    }
}
